# Synthetic testament

Private testament fixture text
